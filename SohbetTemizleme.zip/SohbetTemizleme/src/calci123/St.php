<?php

namespace calci123;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\ConsoleCommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\level\{Level, Position};
use pocketmine\level\sound\AnvilUseSound;
use pocketmine\event\Listener;
use pocketmine\Server;
use pocketmine\Player;
use pocketmine\entity\Effect;
use pocketmine\plugin\PluginBase;

class St extends PluginBase implements Listener{
	
	public $s = "§9Sistem ";
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§aEklenti Aktif Edildi! by calci123");
	}
	
	public function onCommand(CommandSender $g, Command $kmt, string $label, array $args) : bool{
	$player = $g->getPlayer();
		switch($kmt->getName()){
			case "st";
			
			$this->anaForm($player);
		}
		return true;
}
	public function anaForm(Player $player){
		if($player instanceof Player){
			$api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
			$form = $api->createSimpleForm(function (Player $player, array $data){
				if(isset($data[0])){
					switch($data[0]){
					case 0:
						$player->sendMessage("§7» §cBaşarılı");
						break;
						case 1:
						if($player->hasPermission("command.st")){
							$name = $player->getName();
							$this->getServer()->broadcastMessage(" ");
							$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage(" ");$this->getServer()->broadcastMessage($this->s."§8» §bBaşarıyla Sohbet Temizlendi §a✓");$this->getServer()->broadcastMessage($this->s."§8» §bSohbeti Temizleyen Kişi: §c $name ");
			$player->getLevel()->addSound(new AnvilUseSound($player));
			}else{
				$player->sendMessage("§cBu Komutu Kullanma Yetkin Yok!");
			}
						break;
						case 2:
						$name = $player->getName();
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage(" ");
						$player->sendMessage($this->s."§7» §7Başarıyla Sohbet Temizlendi §e$name §a✓");
						
						$player->getLevel()->addSound(new AnvilUseSound($player));;
						}
				}
			});
					$name = $player->getName();
			$form->setTitle($this->s."Sohbet Temizleme Menüsü");
			$form->setContent("§7Hoşgeldin §c$name \n§bKendi Sohbetini Veya Yetkiliysen Sunucu Sohbetini \n§bAşağıdan Temizleyebilirsin.");
			$form->addButton("§cÇıkış\n§7Çıkarsın");
			$form->addButton("§bOyuncu Sohbetini Temizle",1);
			$form->addButton("§aKendi Sohbetini Temizle",1);
			$form->sendToPlayer($player);
		}
		}
}
?>